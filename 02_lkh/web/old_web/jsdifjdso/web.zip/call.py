from pkg.web import flask_run as f
import pandas as pd
pd.DataFrame()

f.myprint()